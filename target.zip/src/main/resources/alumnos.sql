/*create database ALUMNOS;*/

USE ALUMNOS;

/*create table ALUMNO(
	DNI VARCHAR(9) PRIMARY KEY NOT NULL,
    NOMBRE VARCHAR(50) NOT NULL,
    APELLIDOS VARCHAR(100) NOT NULL,
    EDAD int
);*/

/*insert into ALUMNO (DNI, NOMBRE, APELLIDOS, EDAD)
values ('123456789', 'Carlos', 'Alvarez L.', 26);
insert into ALUMNO (DNI, NOMBRE, APELLIDOS, EDAD)
values ('987654321', 'Gorka', 'Cuenca J.', 21);*/

select * from alumno